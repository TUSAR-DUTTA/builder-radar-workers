# `@builder-radar/evidence-contract`

This package is the runtime-safe, database-free, browser-free evidence boundary shared by the
Builder Radar private ingestion application and public worker. It owns engine IDs, adapter payloads,
complete project identity, provenance, lifecycle, publication, failure, scan-cell, and compatibility
definitions.

Build and package from the private repository root:

```powershell
npm run build:evidence-contract
```

The command builds twice, verifies deterministic tarball bytes, writes the immutable artifact and
SHA-512 sidecar under `vendor/`, and mirrors those exact bytes into the adjacent worker checkout.
Both consumers install the exact `file:vendor/builder-radar-evidence-contract-1.0.0.tgz` dependency.

External registry publication is optional for R1. If configured later, publish this exact artifact,
then replace both file dependencies with the exact version `1.0.0` in one coordinated change.
